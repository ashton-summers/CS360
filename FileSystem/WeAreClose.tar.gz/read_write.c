#include "fs.h"

// Calls 'myRead' and returns number of bytes read.
int readFile()
{
    char line[128], buf[BLKSIZE];
    OFT *temp;
    int fd = 0, nbytes = 0;
    printf("Enter a file descriptor and number of bytes to read: ");
    fgets(line, 128, stdin);
    sscanf(line, "%d %d", &fd, &nbytes);
    temp = running->fd[fd];

    if(temp)
    {
        if(temp->mode != 0 && temp->mode != 2)
        {
            printf("The file descriptor entered is not opened for R or RW\n");
            return 0;
        }
    }



    int bytesRead = (myRead(fd, buf, nbytes));
    printf("*************** READ RESULTS **************\n");
    buf[bytesRead + 1] = 0;
    printf("%s\n", buf);
    printf("*************** END READ RESULTS **************\n");
    return bytesRead;
}

// Reads n bytes from the specified file.
int myRead(int fd, char buf[], int nbytes)
{
    int count = 0, lbk, startByte, blk, ibuf[256], dbuf[256];
    OFT * oftp = running->fd[fd];
    MINODE *mip = oftp->mptr;
    int avil = mip->INODE.i_size - oftp->offset;
    int remain;
    char *cq = buf, readBuf[BLKSIZE]; // cq points at buf[ ]


  while (nbytes && avil)
  {

      lbk = oftp->offset / BLKSIZE;
      startByte = oftp->offset % BLKSIZE;

       if (lbk < 12){                     // lbk is a direct block
           blk = mip->INODE.i_block[lbk]; // map LOGICAL lbk to PHYSICAL blk
             get_block(mip->dev, blk, readBuf);
             //printf("ahsdfhaskdjfha\n");
       }
       else if (lbk >= 12 && lbk < 256 + 12)
       {
            get_block(mip->dev, mip->INODE.i_block[12], ibuf);
            printf("blk[12]: %d\n", mip->INODE.i_block[12]);
            blk = (lbk - 12);
            printf("physical blk: %d\n", blk);
            printf("indirect block read: %d\n", ibuf[blk]);
            //printf("indirect blk: %d\n", blk);
            get_block(mip->dev, 520, readBuf);
       }
       else
       {
            //  double indirect blocks
            get_block(mip->dev, mip->INODE.i_block[13], dbuf);
            blk = (lbk / 268 - 1);
            //printf("double indirect blk #: %d\n", blk);

            get_block(mip->dev, dbuf[blk], ibuf);
            blk = (lbk % 268);
            //printf("indirect blk #: %d\n", blk);
            get_block(mip->dev, ibuf[blk], readBuf);
            //printf("ibuf dbl: %d\n", ibuf[blk]);
            //printf("ibuf[blk]: %d\n\n\n", ibuf[blk]);
       }


       /* copy from startByte to buf[ ], at most remain bytes in this block */
       char *cp = readBuf + startByte;
       remain = BLKSIZE - startByte;   // number of bytes remain in readbuf[]
       while (remain > 0)
       {
            *cq++ = *cp++;             // copy byte from readbuf[] into buf[]
             oftp->offset++;           // advance offset
             count++;                  // inc count as number of bytes read
             avil--; nbytes--;  remain--;
             if (nbytes <= 0 || avil <= 0)
                 break;
       }

       // if one data block is not enough, loop back to OUTER while for more ...

   }
   //printf("myread: read %d char from file descriptor %d\n", count, fd);
   return count;   // count is the actual number of bytes read
}


int writeFile()
{
    char line[128], buf[BLKSIZE], tempBuf[BLKSIZE];
    OFT *temp;
    int fd = 0, nbytes = 0;
    printf("Enter a file descriptor: ");
    fgets(line, 128, stdin);
    sscanf(line, "%d", &fd);
    printf("enter a string to write: ");
    fgets(buf, 128, stdin);
    temp = running->fd[fd];

    if(temp)
    {
        if(temp->mode != 1 && temp->mode != 2 && temp->mode != 3)
        {
            printf("The file descriptor entered is not opened for R or RW\n");
            return 0;
        }
    }

    nbytes = strlen(buf);
    buf[strlen(buf) + 1] = 0;

    return(myWrite(fd, buf, nbytes));
}

// Writes nbytes to the file given a descriptor
int myWrite(int fd, char buf[], int nbytes)
{
    int lbk = 0, startByte = 0, blk = 0, remain = 0, tempBytes = nbytes, tempblk;
    OFT *oftp = running->fd[fd];
    MINODE *mip = oftp->mptr;
    char wbuf[BLKSIZE], *cq = buf, dbuf[256], ibuf[256];
    memset(wbuf, 0, 1024);

    while (nbytes > 0 )
    {

          lbk       = oftp->offset / BLKSIZE;
          startByte = oftp->offset % BLKSIZE;

        if (lbk < 12)
        {                         // direct block
            if (mip->INODE.i_block[lbk] == 0)
            {
                mip->INODE.i_block[lbk] = balloc(mip->dev);// MUST ALLOCATE a block                                     but MUST for I or D blocks
            }
           blk = mip->INODE.i_block[lbk];      // blk should be a disk block now
        }
        else if (lbk >= 12 && lbk < 256 + 12)
        {
            if(mip->INODE.i_block[12] == 0)
            {
                mip->INODE.i_block[12] = balloc(mip->dev);
            }
            printf("blk[12]: %d\n", mip->INODE.i_block[12]);

            get_block(mip->dev, mip->INODE.i_block[12], ibuf);

            tempblk = (lbk - 12);
            if (ibuf[tempblk] == 0)
            {
                blk = balloc(mip->dev);
                get_block(mip->dev, blk, wbuf);
                printf("blk: %d\n", blk);
                get_block(mip->dev, blk, ibuf);
            }
            else
            {
                blk = ibuf[tempblk];
            }

            printf("here is the end\n");

        }
        else
        {
            //return 1;
            if(mip->INODE.i_block[13] == 0)
            {
                blk = balloc(mip->dev);
                mip->INODE.i_block[13] = blk;
            }

            get_block(mip->dev, blk, dbuf);
            tempblk = (lbk / 268 - 1);
            //printf("temp blk: %d\n", tempblk);
            //printf("\n\n\ndouble indirect blk #: %d\n", blk);
            if(dbuf[tempblk] == 0)
            {
                blk = balloc(mip->dev);
                dbuf[tempblk] = blk;
                get_block(mip->dev, blk, ibuf);
            }
            else
            {
                blk = dbuf[tempblk];
                get_block(mip->dev, blk, ibuf);
            }

            tempblk = (lbk - 268);


            if(ibuf[tempblk] == 0)
            {
                blk = balloc(mip->dev);
                printf("blk = balloc\n");
                ibuf[tempblk] = blk;
            }
            else
            {
                blk = ibuf[tempblk];
                //printf("blk = ibuf[tempblk]\n");
            }
            printf("LNK*******: %d\n", lbk);
            printf("dbl blk: %d\n", blk);

        }

     /* all cases come to here : write to the data block */
        //get_block(mip->dev, blk, wbuf);   // read disk block into wbuf[ ]
        char *cp = wbuf + startByte;      // cp points at startByte in wbuf[]
        remain = BLKSIZE - startByte;     // number of BYTEs remain in this block

        while (remain > 0){               // write as much as remain allows
                *cp++ = *cq++;              // cq points at buf[ ]
                nbytes--; remain--;         // dec counts
                oftp->offset++;             // advance offset
                if (oftp->offset > mip->INODE.i_size)  // especially for RW|APPEND mode
                mip->INODE.i_size++;    // inc file size (if offset > fileSize)
                if (nbytes <= 0) break;     // if already nbytes, break
        }
        put_block(mip->dev, blk, wbuf);   // write wbuf[ ] to disk

     // loop back to while to write more .... until nbytes are written
  }

  mip->dirty = 1;       // mark mip dirty for iput()
  iput(mip);
  printf("wrote %d chars into file descriptor fd=%d\n", tempBytes, fd);
  return nbytes;
}

// Displays the contents of a file to the screen
int myCat(char *path)
{
    char myBuf[BLKSIZE];
    int n = 0, fd = -1;

    printf("*************** FILE CONTENTS ***************\n");
    fd = openFile(path, 0);

    if(fd == -1)
    {
        return -1;
    }
    while(n = myRead(fd, myBuf, 1024)) // Read n bytes.
    {
        myBuf[n] = 0;
        printf("%s", myBuf);
        memset(myBuf, 0, 1024);
    }
    printf("\n*************** END FILE CONTENTS ***************\n");

    closeFile(fd);

}

// Copies contents of the source to the destination
int myCp(char *source, char *dest)
{
    int fd = openFile(source, 0);
    int gd = openFile(dest, 1);
    int n;
    char buf[BLKSIZE];
    pfd();

    if (fd == -1 || gd == -1)
    {
        return -1;
    }

    while(n = myRead(fd, buf, BLKSIZE))
    {
        myWrite(gd, buf, n);
    }
    closeFile(fd);
    closeFile(gd);
}

//
int myMV(char source[], char dest[])
{
    MINODE *mip;
    char temp[256];
    int fd;

    strcpy(temp, source);

  fd = openFile(source, 0);


    if(fd < 0)
    {
        printf("Source file does not exist\n");
        return -1;
    }

    mip = running->fd[fd]->mptr;

    if(mip->dev == dev)
    {
        myLink(source, dest);
        myUnlink(temp);
        //printf("link count: %d\n", mip->refCount);
        mip->dirty = 1;
        iput(mip);
        return 1;
    }
    else
    {
      myCp(source, dest);
      myUnlink(source);
    }
}


