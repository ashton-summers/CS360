#include "fs.h"

// Mounts file system to a new mounting point
int mount(char* name, char *mountPoint)
{
    int i = 0, openMountSlot = 0, fd = 0, pino, mdev;
    char buf[BLKSIZE], dirname[128], temp[128];
    SUPER *msp;
    MountEntry entry;
    MINODE *mip;

    // If mount with no parameters, print all mount devices
    if (name[0] == '\0')
    {
        for(i = 0; i < NMOUNT; i++)
        {
            if (strcmp(mountTable[i].name, "") != 0)
            {
                printf("mountTable[%d]: %s\n", i, mountTable[i].name);
            }
        }
        return -1;
    }


    // Check to see if name is already mounted
    for (i = 0; i < NMOUNT; i++)
    {
        if (strcmp(name, mountTable[i].name) == 0)
        {
            printf("The filesystem with name specified has already been mounted\n");
            return -1;
        }
    }

    for (i = 0; i < NMOUNT; i++)
    {
        if (strcmp(mountTable[i].name, "") == 0)
        {
            break;
        }
    }

    openMountSlot = i;

    fd = openFile(name, 2);
    if(fd < 0)
    {
        printf("File failed to open\n");
        return -1;
    }


    dev = fd;
    get_block(fd, 1, buf);
    msp = (SUPER *)buf;

    if(msp->s_magic != 0xEF53)
    {
        printf("This is not an ext2 filesystem\n");
        return 1;
    }

    entry.ninodes = sp->s_inodes_count;
    entry.nblocks = sp->s_blocks_count;
    get_block(dev, 2, buf);

    entry.bmap = gp->bg_block_bitmap;
    entry.imap = gp->bg_block_bitmap;
    entry.startBlock = gp->bg_inode_table;
    entry.dev = dev;
    strcpy(entry.name, name);

    strcpy(entry.mountpoint, mountPoint);
    mountTable[openMountSlot] = entry;

    pino = getino(&dev, mountPoint);
    mip = iget(dev, pino);

    // Check to make sure mount point is dir
    if (!S_ISREG(mip->INODE.i_mode))
    {
        printf("Cannot mount. %s is not a directory\n", mountPoint);
    }

    if (mip == running->cwd)
    {
        printf("Cannot mount: %s is in use\n", mountPoint);
    }

    mountTable[openMountSlot].inode = mip;

    mip->mounted = 1;
    mip->refCount++;
    mip->mptr = &mountTable[openMountSlot];
    mip->dirty = 1;

    iput(mip);

    return 0;





}
