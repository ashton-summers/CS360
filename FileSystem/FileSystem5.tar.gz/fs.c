#include "fs.h"

// Init file system
int init()
{
    int i = 0;
    for(i = 0; i < NMINODE; i++)
    {
        minode[i].refCount = 0;
    }
    for (i = 0; i < NFD; i++)
    {
        proc[0].fd[i] = 0;
        proc[1].fd[i] = 0;
    }
    proc[0].pid = 1;
    proc[0].uid = 0;
    proc[0].cwd = 0;
    proc[1].pid = 2;
    proc[1].uid = 1;
    proc[1].cwd = 0;

     // Get super block info
    get_block(fd, 1, buf);
    sp = (SUPER *)buf;
    ninodes = sp->s_inodes_count;
    nblocks = sp->s_blocks_count;

    // Get group descriptor info
    get_block(fd, 2, buf);
    gp = (GD *)buf;

    printf("GD info: %d %d %d %d %d %d %d\n",
        gp->bg_block_bitmap,
        gp->bg_inode_bitmap,
        gp->bg_inode_table,
        gp->bg_free_blocks_count,
        gp->bg_free_inodes_count,
        gp->bg_used_dirs_count);

    iblock = gp->bg_inode_table;
    bmap = gp->bg_block_bitmap;
    imap = gp->bg_inode_bitmap;
    printf("bmap = %d   imap = %d  inode_start(iblock) = %d\n", bmap, imap, iblock);

}

int mount_root()
{
    printf("mount_root()\n");
    root = iget(dev, 2);
}

int get_block(int fd, int blk, char buf[ ])
{
  lseek(fd, (long)blk*BLKSIZE, 0);
  read(fd, buf, BLKSIZE);
}
int put_block(int fd, int blk, char buf[ ])
{
  lseek(fd, (long)blk*BLKSIZE, 0);
  write(fd, buf, BLKSIZE);
}
// prints the bit map for inodes
void i_map()
{
  char buf[BLKSIZE];
  int  imap, ninodes;
  int  i;

  // read SUPER block
  get_block(fd, 1, buf);
  sp = (SUPER *)buf;

  ninodes = sp->s_inodes_count;
  printf("ninodes = %d\n", ninodes);

  // read Group Descriptor 0
  get_block(fd, 2, buf);
  gp = (GD *)buf;

  imap = gp->bg_inode_bitmap;
  printf("bmap = %d\n", imap);

  // read inode_bitmap block
  get_block(fd, imap, buf);

  for (i=0; i < ninodes; i++)
  {
    (tst_bit(buf, i)) ?	putchar('1') : putchar('0');
    if (i && (i % 8)==0)
       printf(" ");
  }
  printf("\n\n");
}

// prints the bit map for block
void b_map()
{
  char buf[BLKSIZE];
  int  bmap, ninodes;
  int  i;

  // read SUPER block
  get_block(fd, 1, buf);
  sp = (SUPER *)buf;

  ninodes = sp->s_inodes_count;
  printf("ninodes = %d\n", ninodes);

  // read Group Descriptor 0
  get_block(fd, 2, buf);
  gp = (GD *)buf;

  bmap = gp->bg_block_bitmap;
  printf("bmap = %d\n", bmap);

  // read inode_bitmap block
  get_block(fd, bmap, buf);

  for (i=0; i < ninodes; i++)
  {
    (tst_bit(buf, i)) ?	putchar('1') : putchar('0');
    if (i && (i % 8)==0)
       printf(" ");
  }
  printf("\n\n");
}

void findDir()
{
    int i = 0, block = 0, offset = 0;
    // Read SUPER block at offset 1024
    get_block(fd, 1, buf);
    sp = (SUPER *)buf;

    printf("Checking ext2 FS...");
    if (sp->s_magic != 0xEF53) {
        printf("Magic: %x; this is not an EXT2 fs\n", sp->s_magic);
        exit(2);
    }
    else
        printf("FS loaded\n");

    super();
    // Read GD block at (block0 + 1)
    get_block(fd, 2, buf);
    gp = (GD *)buf;

    printf("GD info: %d %d %d %d %d %d %d\n",
        gp->bg_block_bitmap,
        gp->bg_inode_bitmap,
        gp->bg_inode_table,
        gp->bg_free_blocks_count,
        gp->bg_free_inodes_count,
        gp->bg_used_dirs_count);

    iblock = gp->bg_inode_table;
    printf("Inodes beginning block: %d\n", iblock);

    // Read first inode block to get root inode -- block2
    get_block(fd, iblock, buf);
    ip = (INODE *)buf + 1;

     printf(" -- Root node info --\n");
    //printf("mode=%4x  ", ip->inode);
    printf("uid=%d  gid=%d\n", ip->i_uid, ip->i_gid);
    //printf("size=%d\n", i->i_size);
    printf("time=%s", ctime(&ip->i_ctime));
    printf("link=%d\n", ip->i_links_count);
    printf("i_block[0]=%d\n", ip->i_block[0]);
    //rootblock = ip->i_block[0];
    printf(" -- -- -- -- -- -- --\n");

    printf("******* ROOT DIR ENTRIES ********\n");

    if (!dirNames[0])
    {
        search(ip, ".");
        int j;
        printf(" --------- DISK BLOCKS ----------\n");
         for (j = 0; j < ip->i_blocks; j++) {
            printf("iblock[%2d] = %d\n", j, ip->i_block[j]);
        }
        return;
    }
    // Search for the inode in block
    for(i = 0; i < n; i++)
    {
        printf("searching for %s in %x\n", dirNames[i], ip);
        printf("i_block[0] = %d\n", ip->i_block[0]);
        int ino = search(ip, dirNames[i]);
        if (ino == 0)
        {
            printf("Cannot find name '%s'\n", dirNames[i]);
            return;
        }
        printf("found %s: ino = %d\n", dirNames[i], ino);
        block = (ino - 1) / 8 + iblock;
        offset = (ino - 1) % 8;
        printf("blk = %d   offset = %d\n\n", block, offset);
        get_block(fd, block, buf);
        ip = (INODE *)buf + offset;

        printf("size = %d   blocks = %d\n", 1024, ip->i_blocks);
        printf(" --------- DISK BLOCKS ----------\n");
        int j;
        for (j = 0; j < ip->i_blocks; j++) {
            printf("iblock[%2d] = %d\n", j, ip->i_block[j]);
        }
    }
}

// Accepts an INODE to root directory
// Searches directory for 'name' file
int search(INODE *ip, char * name)
{
    int i, found = 0;
    char * cp;

    if (!ip) {
        printf("Inode argument cannot be null\n");
        exit(1);
    }

    printf("i_mode: %x", ip->i_mode);
    if (!S_ISDIR(ip->i_mode)) {
        printf("INode must be for directory\n");
        exit(2);
    }

    // Look at rootblock
    get_block(fd, ip->i_block[0], dbuf);
    dp = (_DIR *)dbuf;
    cp = dbuf;
    printf("name in seach: %s", dp->name);

    while (cp < &dbuf[BLKSIZE]) {
        strncpy(sbuf, dp->name, dp->name_len);
        sbuf[dp->name_len] = 0;

        // If we found the correct node,
        // store its number
        if (strcmp(sbuf, name) == 0) {
            found = dp->inode;
            return found;
        }

        printf("%4d %4d %4d %s\n",
            dp->inode, dp->rec_len, dp->name_len, sbuf);
        cp += dp->rec_len;
        dp = (DIR *)cp;
    }

    return found;
}



void groupDescriptor()
{

  // read SUPER block
  get_block(fd, 2, buf);
  gp = (GD *)buf;

  printf("EXT2 FS OK\n");
  printf("bg_block_bitmap = %d\n", gp->bg_block_bitmap);
  printf("bg_inode_bitmap = %d\n", gp->bg_inode_bitmap);
  printf("bg_inode_table = %d\n", gp->bg_inode_table);
  printf("bg_inode_bitmap = %d\n", gp->bg_inode_bitmap);
  printf("bg_free_blocks_count = %d\n", gp->bg_free_blocks_count);
  printf("bg_free_inodes_count = %d\n\n", gp->bg_free_inodes_count);

}

void super()
{
  // read SUPER block
  get_block(fd, 1, buf);
  sp = (SUPER *)buf;

  // check for EXT2 magic number:

  printf("s_magic = %x\n", sp->s_magic);
  if (sp->s_magic != 0xEF53){
    printf("NOT an EXT2 FS\n");
    exit(1);
  }

  printf("EXT2 FS OK\n");

  printf("s_inodes_count = %d\n", sp->s_inodes_count);
  printf("s_blocks_count = %d\n", sp->s_blocks_count);

  printf("s_free_inodes_count = %d\n", sp->s_free_inodes_count);
  printf("s_free_blocks_count = %d\n", sp->s_free_blocks_count);
  printf("s_first_data_blcok = %d\n", sp->s_first_data_block);


  printf("s_log_block_size = %d\n", sp->s_log_block_size);
  //printf("s_log_frag_size = %d\n", sp->s_log_frag_size);

  printf("s_blocks_per_group = %d\n", sp->s_blocks_per_group);
  //printf("s_frags_per_group = %d\n", sp->s_frags_per_group);
  printf("s_inodes_per_group = %d\n", sp->s_inodes_per_group);


  printf("s_mnt_count = %d\n", sp->s_mnt_count);
  printf("s_max_mnt_count = %d\n", sp->s_max_mnt_count);

  printf("s_magic = %x\n", sp->s_magic);

  printf("s_mtime = %s", ctime(&sp->s_mtime));
  printf("s_wtime = %s\n\n", ctime(&sp->s_wtime));


}

void inode()
{
  char buf[BLKSIZE];

  // read GD
  get_block(fd, 2, buf);
  gp = (GD *)buf;
  /****************
  printf("%8d %8d %8d %8d %8d %8d\n",
	 gp->bg_block_bitmap,
	 gp->bg_inode_bitmap,
	 gp->bg_inode_table,
	 gp->bg_free_blocks_count,
	 gp->bg_free_inodes_count,
	 gp->bg_used_dirs_count);
  ****************/
  iblock = gp->bg_inode_table;   // get inode start block#
  printf("inode_block=%d\n", iblock);

  // get inode start block
  get_block(fd, iblock, buf);

  ip = (INODE *)buf + 1;         // ip points at 2nd INODE

  printf("mode=%4x ", ip->i_mode);
  printf("uid=%d  gid=%d\n", ip->i_uid, ip->i_gid);
  printf("size=%d\n", ip->i_size);
  printf("time=%s", ctime(&ip->i_ctime));
  printf("link=%d\n", ip->i_links_count);
  printf("i_block[0]=%d\n", ip->i_block[0]);

 /*****************************
  u16  i_mode;        // same as st_imode in stat() syscall
  u16  i_uid;                       // ownerID
  u32  i_size;                      // file size in bytes
  u32  i_atime;                     // time fields
  u32  i_ctime;
  u32  i_mtime;
  u32  i_dtime;
  u16  i_gid;                       // groupID
  u16  i_links_count;               // link count
  u32  i_blocks;                    // IGNORE
  u32  i_flags;                     // IGNORE
  u32  i_reserved1;                 // IGNORE
  u32  i_block[15];                 // IMPORTANT, but later
 ***************************/
}



void tokenize()
{
    char *s;
    int i = 1;
    char temp[256];
    strcpy(temp, pathName);
     s = strtok(temp, "/ \n");
     if (s)
     {
        dirNames[0] = (char *)malloc(strlen(s) + 1);
        strcpy(dirNames[0], s);

        // Parse all dir names from the path and store in array of strings
        while (s = strtok(NULL, "/\n"))
        {
            dirNames[i] = (char *)malloc(strlen(s) + 1);
            strcpy(dirNames[i], s);
            i++;
        }

        dirNames[i] = 0;
        n = i; // n: number of dir names in the path
    }

}

// Change current working directory
int changeDir (char *pathname)
{
    MINODE *mip;
    int ino = getino(&dev, pathname);
    printf("%d\n", ino);
    mip = iget(dev, ino);

    if(!S_ISDIR(mip->INODE.i_mode))
    {
        printf("The pathname entered is not a directory\n");
        strcpy(prevWd, wd);
        strcpy(wd, dirname(pathTemp));
        return;
    }
    else
    {
        iput(running->cwd); // Dispose of the old cwd
        running->cwd = mip; // new cwd points to inode in memory

    }
}

// Display the contents of the file
int ls(char *pathname)
{
    MINODE *mip;
    DIR *dir;
	struct dirent *file;
	int ino;
	printf("path in ls: %s", pathname);
	if (!pathname[0])
	{
        ino = running->cwd->ino;
	}
	else
	{
        ino = getino(&dev, pathname);
	}
    printf("inode num: %d\n", ino);
    mip = iget(dev, ino);
    printf("mipnode: %d  mode: %x\n", mip->ino, mip->INODE.i_mode);

    if(S_ISDIR(mip->INODE.i_mode)) // if inode is a dir
    {
        printf("Ls-ing dir...\n");
        return ls_aux(&mip->INODE);

        // skip all of this
        printf("inode is dir... Path: %s\n", pathname);
        dir = opendir(pathName);
        printf("dir: %x\n", dir);
        while(file = readdir(dir))
        {
            printf("ls_file on %s...\n", file->d_name);
            ls_file(file->d_name);
            printf("\n");
        }
    }
    else // inode is a file
    {
        printf("inode is file...\n");
        printf("%s\n", pathname);
        return;

       ls_file(pathName);
    }
}

int ls_aux(INODE * ip) {
    char lsbuf[BLKSIZE];
    char lss[BLKSIZE];
    _DIR * lsdp;
    char * lscp;

    // Look at rootblock
    get_block(fd, ip->i_block[0], lsbuf);
    lsdp = (_DIR *)lsbuf;
    lscp = lsbuf;

    while (lscp < &lsbuf[BLKSIZE]) {
        //printf("Copying...\n");
        strncpy(lss, lsdp->name, lsdp->name_len);
        lss[lsdp->name_len] = 0;
        //printf("Name: '%d' Check: '%d'\n", sbuf[0], name[0]);

        printf("%4d %4d %4d %s\n",
            lsdp->inode, lsdp->rec_len, lsdp->name_len, lss);
        lscp += lsdp->rec_len;
        lsdp = (_DIR *)lscp;
    }
    printf("Exiting lsAux...\n");
}

// Helper function of ls
int ls_file(char *fname)
{
  struct stat fstat, *sp;
  char *t1 = "xwrxwrxwr-------";
  char *t2 = "----------------";

  int r, i;
  char ftime[64];

  sp = &fstat;
  //printf("name=%s\n", fname); getchar();

  if ( (r = lstat(fname, &fstat)) < 0){
     printf("can't stat %s\n", fname);
     exit(1);
  }

  if ((sp->st_mode & 0xF000) == 0x8000)
     printf("%c",'-');
  if ((sp->st_mode & 0xF000) == 0x4000)
     printf("%c",'d');
  if ((sp->st_mode & 0xF000) == 0xA000)
     printf("%c",'l');

  for (i=8; i >= 0; i--){
    if (sp->st_mode & (1 << i))
	printf("%c", t1[i]);
    else
	printf("%c", t2[i]);
  }

  printf("%4d ",sp->st_nlink);
  printf("%4d ",sp->st_gid);
  printf("%4d ",sp->st_uid);
  printf("%8d ",sp->st_size);

  // print time
  strcpy(ftime, ctime(&sp->st_ctime));
  ftime[strlen(ftime)-1] = 0;
  printf("%s  ",ftime);

  // print name
  printf("%s", basename(fname));

  char *linkname;
  // print -> linkname if it's a symbolic file
  if ((sp->st_mode & 0xF000)== 0xA000){ // YOU FINISH THIS PART
     // use readlink() SYSCALL to read the linkname
	readlink(fname, linkname, PATH_MAX);
     printf(" -> %s", linkname);
  }
  printf("\n");
}

// Prints the current working dir
void pwd(MINODE *cwd, char name[], int i)
{
    MINODE *mip;
    INODE *ip;
    char buf[1024], *cp, temp[256];
    int ino, pino = 0, disp, blk, j = 0;
    int childino = cwd->ino;

    pino = search(&cwd->INODE, ".."); //get parent ino
    blk = (pino - 1) / 8 + iblock; // Get block parent is in
    disp = (pino - 1) % 8; // Get inode in block of parent
    get_block(dev, blk, buf);
    ip = (INODE *)buf + disp; // set ip to parent inode

    mip = iget(dev, pino); // get the parent inode into memory

    if(cwd->ino == 2)
    {
        if (i == 0) // if i parameter is 0, we have not recursed and started at root
        {
            printf("/");
        }
        return;
    }

    // Look at rootblock
    get_block(fd, ip->i_block[0], dbuf);
    dp = (_DIR *)dbuf;
    cp = dbuf;
    // printf("name in search: %s\n", dp->name);

    while (cp < &dbuf[BLKSIZE]) {
        strncpy(sbuf, dp->name, dp->name_len);
        sbuf[dp->name_len] = 0;

        // Store the name for recursive call
        // if the ino == child ino
        if (dp->inode == childino) {
            strcpy(temp, sbuf);
            strcpy(name, sbuf);
            printf("/%s",temp);
        }
        cp += dp->rec_len;
        dp = (_DIR *)cp;
    }

    pwd(mip, &temp[0], i + 1);
    printf("/%s", name);
}


