#include "fs.h"

void makeDir(char *path)
{
    MINODE *pip;
    char parent[256], child[1024], temp[256];
    int pino;

    // If path is absolute
    if(path[0] == '/')
    {
        dev = root->dev;
        pip = root;
    }
    else // Path is relative
    {
        dev = running->cwd->dev;
        pip = running->cwd;
    }

    // Copy to temp first, so we don't destroy our parent and child arrays
    strcpy(temp, path);
    strcpy(parent, dirname(temp));
    printf("parent: %s\n", parent);
    strcpy(temp, path);
    strcpy(child, basename(temp));
    printf("child: %s\n", child);

    pino = getino(&dev, parent);
    pip = iget(dev, pino);

    // Check to make sure parent is a dir
    if(!S_ISDIR(pip->INODE.i_mode))
    {
        printf("Error: Not a directory\n");
        return;
    }
    else
    {
        // Check to make sure child does not exist already
        if (search(pip, child) == 0) // Okay to mkdir
        {
            mymkdir(pip, child);
        }
        else
        {
            printf("This directory already exists\n");
            iput(pip);
            return;
        }
    }

    // Increment paren't link count, mark as modified and write to disk
    pip->INODE.i_links_count++;
    pip->dirty = 1;
    iput(pip);
}

int mymkdir(MINODE *pip, char *name)
{
    int ino, bno, i;
    char buf[BLKSIZE], *cp;
    _DIR *dp;
    MINODE *mip;
    INODE *ip;

    // Allocate inode and disk block to insert
    ino = ialloc(dev);
    bno = balloc(dev);

    // Load inode into memory
    mip = iget(dev, ino);

    ip = &mip->INODE;
    ip->i_mode = 0x41ED;
    ip->i_uid = running->uid;
    ip->i_gid = running->pid;
    ip->i_size = BLKSIZE;
    ip->i_links_count = 2;
    ip->i_atime = ip->i_ctime = ip->i_mtime = time(0L);
    ip->i_blocks = 2;
    ip->i_block[0] = bno;

    for(i = 1; i < 15; i++)
        ip->i_block[i] = 0;

    mip->dirty = 1;
    iput(mip);

    get_block(dev, bno, buf);

    // Set dir structure to start of buf area
    dp = (_DIR *)buf;
    cp = buf;

    dp->inode = ino;
    dp->rec_len = 4 * ((8 + strlen(".") + 3) / 4);
    printf(". rec len = %d  ino = %d\n", dp->rec_len, ino);
    dp->name_len = strlen(".");
    strcpy(dp->name, ".");


    // Write '.' information to buf
     cp += dp->rec_len;
    dp = (_DIR *)cp;

    // Move to next entry. Set '..' info (parent information)
    dp->inode = pip->ino;
    dp->name_len = strlen("..");
    dp->rec_len = BLKSIZE - 12; // First entry is 12 bytes
    printf(".. rec len = %d   pino = %d\n", dp->rec_len, dp->inode);
    strcpy(dp->name, "..");



    put_block(dev, bno, &buf);
    enterName(pip, ino, name);
}

// Enter child name into new data block
int enterName(MINODE *pip, int mino, char *name)
{
    char buf[BLKSIZE], buf2[BLKSIZE], *temp;
    _DIR *dp;
    int i = 0, need_len, ideal_len, remaining, cp;

    while(pip->INODE.i_block[i])
    {
        i++;
    }
    i--;
    get_block(dev, pip->INODE.i_block[i], buf);
    dp = (_DIR *)buf;
    temp = buf;
    cp = 0;

    // Step to last entry in block
    while(cp + dp->rec_len < BLKSIZE)
    {
        char sbuf[256];
        strncpy(sbuf, dp->name, dp->name_len);
        sbuf[dp->name_len] = 0;
        printf("dir entry: %s\n", dp->name);
        printf("dp rec len: %d\n", dp->rec_len);
        cp += dp->rec_len;
        temp += dp->rec_len;
        dp = (_DIR *)temp;
    }

    ideal_len = 4 * ((8 + dp->name_len + 3) / 4);
    remaining = dp->rec_len - ideal_len;

    cp = dp->rec_len;

    if(remaining >= need_len)
    {
        // Trim last entry to ideal len
        dp->rec_len = ideal_len;
        // Enter new entry
        temp += dp->rec_len;
        dp = (_DIR *)temp;
        dp->inode = mino;
        dp->rec_len = remaining;
        dp->name_len = strlen(name);
        strcpy(dp->name, name);
        put_block(dev, pip->INODE.i_block[i], buf);
    }
    else // No space in existing datablock, create new
    {
        i++;
        int blk = balloc(dev);
        pip->INODE.i_size += BLKSIZE;
        get_block(dev, blk, buf2);
        dp = (_DIR *)buf;
        dp->inode = mino;
        dp->rec_len = BLKSIZE;
        dp->name_len = strlen(name);
        strcpy(dp->name, name);
        put_block(dev, pip->INODE.i_block[i], buf2);
    }

    pip->dirty = 1;
}


