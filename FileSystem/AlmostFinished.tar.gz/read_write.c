#include "fs.h"

// Calls 'myRead' and returns number of bytes read.
int readFile()
{
    char line[128], buf[BLKSIZE];
    OFT *temp;
    int fd = 0, nbytes = 0;
    printf("Enter a file descriptor and number of bytes to read: ");
    fgets(line, 128, stdin);
    sscanf(line, "%d %d", &fd, &nbytes);
    temp = running->fd[fd];

    if(temp)
    {
        if(temp->mode != 0 && temp->mode != 2)
        {
            printf("The file descriptor entered is not opened for R or RW\n");
            return 0;
        }
    }


    return(myRead(fd, buf, nbytes));

}

// Reads n bytes from the specified file.
int myRead(int fd, char buf[], int nbytes)
{
    int count = 0, lbk, startByte, blk, ibuf[256], dbuf[256];
    OFT * oftp = running->fd[fd];
    MINODE *mip = oftp->mptr;
    int avil = mip->INODE.i_size - oftp->offset;
    int remain;
    char *cq = buf, readBuf[BLKSIZE]; // cq points at buf[ ]


  while (nbytes && avil)
  {

      lbk = oftp->offset / BLKSIZE;
      startByte = oftp->offset % BLKSIZE;

       if (lbk < 12){                     // lbk is a direct block
           blk = mip->INODE.i_block[lbk]; // map LOGICAL lbk to PHYSICAL blk
             get_block(mip->dev, blk, readBuf);
       }
       else if (lbk >= 12 && lbk < 256 + 12)
       {
            get_block(mip->dev, mip->INODE.i_block[12], ibuf);
            blk = (lbk - 12);
            get_block(mip->dev, ibuf[blk], readBuf);
       }
       else
       {
            //  double indirect blocks
            get_block(mip->dev, mip->INODE.i_block[13], dbuf);
            blk = (lbk / 268 - 1);
            get_block(mip->dev, dbuf[blk], ibuf);
            blk = (lbk % 256);
            get_block(mip->dev, ibuf[blk], readBuf);
       }


       /* copy from startByte to buf[ ], at most remain bytes in this block */
       char *cp = readBuf + startByte;
       remain = BLKSIZE - startByte;   // number of bytes remain in readbuf[]
       while (remain > 0)
       {
            *cq++ = *cp++;             // copy byte from readbuf[] into buf[]
             oftp->offset++;           // advance offset
             count++;                  // inc count as number of bytes read
             avil--; nbytes--;  remain--;
             if (nbytes <= 0 || avil <= 0)
                 break;
       }

       // if one data block is not enough, loop back to OUTER while for more ...

   }
   //printf("myread: read %d char from file descriptor %d\n", count, fd);
   return count;   // count is the actual number of bytes read
}


int writeFile()
{
    char line[128], buf[BLKSIZE], tempBuf[BLKSIZE];
    OFT *temp;
    int fd = 0, nbytes = 0;
    printf("Enter a file descriptor: ");
    fgets(line, 128, stdin);
    sscanf(line, "%d", &fd);
    printf("enter a string to write: ");
    fgets(buf, 128, stdin);
    temp = running->fd[fd];

    if(temp)
    {
        if(temp->mode != 1 && temp->mode != 2 && temp->mode != 3)
        {
            printf("The file descriptor entered is not opened for R or RW\n");
            return 0;
        }
    }

    nbytes = strlen(buf);
    buf[strlen(buf) - 1] = 0;

    return(myWrite(fd, buf, nbytes));
}

// Writes nbytes to the file given a descriptor
int myWrite(int fd, char buf[], int nbytes)
{
    int lbk, startByte, blk, remain, tempBytes = nbytes, ibuf[256], dbuf[256];
    char wbuf[1024];
    OFT *oftp = running->fd[fd];
    MINODE *mip;


     while (nbytes > 0 )
     {

          lbk = oftp->offset / BLKSIZE;
          startByte = oftp->offset % BLKSIZE;
          mip = running->fd[fd]->mptr;

     if (lbk < 12)
     {                         // direct block
        if (mip->INODE.i_block[lbk] == 0)
        {

           mip->INODE.i_block[lbk] = balloc(mip->dev);// MUST ALLOCATE a block

        }
        blk = mip->INODE.i_block[lbk];      // blk should be a disk block now
        get_block(mip->dev, blk, wbuf);
     }
    else if (lbk >= 12 && lbk < 256 + 12)
    {
        if(mip->INODE.i_block[12] == 0)
        {
            mip->INODE.i_block[12] = balloc(mip->dev);
        }
        get_block(mip->dev, mip->INODE.i_block[12], ibuf);
        blk = (lbk - 12);
        if(ibuf[blk] == 0)
        {
            ibuf[blk] = balloc(mip->dev);
        }
        get_block(mip->dev, ibuf[blk], wbuf);
    }
    else
    {
        //  double indirect blocks
        if(mip->INODE.i_block[13] == 0)
        {
            mip->INODE.i_block[13] = balloc(mip->dev);
        }

        get_block(mip->dev, mip->INODE.i_block[13], dbuf);
        blk = (lbk / 268 - 1);

        if(dbuf[blk] == 0)
        {
            dbuf[blk] = balloc(mip->dev);
        }

        get_block(mip->dev, dbuf[blk], ibuf);
        blk = (lbk % 256);

        if(ibuf[blk] == 0)
        {
            blk = balloc(mip->dev);
        }
        get_block(mip->dev, ibuf[blk], wbuf);
    }

     char *cp = wbuf + startByte;      // cp points at startByte in wbuf[]
     remain = BLKSIZE - startByte;     // number of BYTEs remain in this block

     while (remain > 0)
     {               // write as much as remain allows
           *cp++ = *buf++;              // cq points at buf[ ]
           nbytes--; remain--;         // dec counts
           oftp->offset++;             // advance offset
           if (oftp->offset > mip->INODE.i_size)  // especially for RW|APPEND mode
               mip->INODE.i_size++;    // inc file size (if offset > fileSize)
           if (nbytes <= 0) break;     // if already nbytes, break
     }
     put_block(mip->dev, blk, wbuf);   // write wbuf[ ] to disk

     // loop back to while to write more .... until nbytes are written
  }

  mip->dirty = 1;       // mark mip dirty for iput()
  iput(mip);
  printf("wrote %d char into file descriptor fd=%d\n", tempBytes - 1, fd);
  return nbytes;
}

// Displays the contents of a file to the screen
int myCat(char *path)
{
    char myBuf[BLKSIZE];
    int n = 0, fd = -1;

    printf("*************** FILE CONTENTS ***************\n");
    fd = openFile(path, 0);
    while(n = myRead(fd, myBuf, 1024))
    {
        myBuf[n] = 0;
        printf("%s", myBuf);
    }
    printf("\n*************** END FILE CONTENTS ***************\n");

    closeFile(fd);

}

// Copies contents of the source to the destination
int myCp(char *source, char *dest)
{
    int fd = openFile(source, 0);
    int gd = openFile(dest, 1);
    int n;
    char buf[BLKSIZE];

    while(n = myRead(fd, buf, BLKSIZE))
    {
        myWrite(gd, buf, n);
    }
    closeFile(fd);
    closeFile(gd);
}


